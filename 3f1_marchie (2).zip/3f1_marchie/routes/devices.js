import express from "express";
import { devices } from "../controllers/devices.js";


const router = express.Router();

router.get("/devices", devices.all);
router.post("/devices", devices.insert);
router.get("/devices/:id", devices.findOne);
router.put("/devices/:id", devices.update);
router.delete("/devices/:id", devices.delete);

export default router;