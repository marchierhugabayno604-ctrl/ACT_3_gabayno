
  /*
    MIT License
    
    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    */
    
import express from "express";
import { homePage } from "../controllers/homeController.js";
import { profile } from "../controllers/profile.js";
import { product } from "../controllers/product.js";
import { category } from "../controllers/category.js";
import { order } from "../controllers/order.js"
import { supplier } from "../controllers/supplier.js"
import { devices } from "../controllers/devices.js";
import { fruits } from "../controllers/fruits.js";


const router = express.Router();
router.get("/home", homePage);

import { loginPage, registerPage, forgotPasswordPage, dashboardPage, loginUser, registerUser, logoutUser } from "../controllers/authController.js";


router.get("/login", loginPage);
router.post("/login", loginUser);
router.get("/register", registerPage);
router.post("/register", registerUser);
router.get("/forgot-password", forgotPasswordPage);
router.get("/dashboard", dashboardPage);
router.get("/logout", logoutUser);

// 1. Profile Routes 
router.get("/profile", profile.index);
router.get("/profile", profile.all);
router.post("/profile", profile.insert);
router.get("/profile/:id", profile.getById);
// 2cre. Product Routes 
router.get("/product", product.all);
router.get("/product/:id", product.getById);
router.post("/product", product.insert);
// 3. Category Routes
router.get("/category", category.all);
router.get("/category/:id", category.getById);
router.post("/category", category.insert);
// 4. Order Routes
router.get("/order", order.all);
router.get("/order/:id", order.getById);
router.post("/order", order.insert);
// 5. Supplier Routes 
router.get("/supplier", supplier.all);
router.get("/supplier/:id", supplier.getById);
router.post("/supplier", supplier.insert);


router.get("/devices", devices.all);
router.post("/devices", devices.insert);
router.get("/devices/:id", devices.findOne);
router.put("/devices/:id", devices.update);
router.delete("/devices/:id", devices.delete);
    


router.get("/", fruits.index);
router.get("/add", fruits.add);
router.post("/insert", fruits.insert);
router.get("/edit/:id", fruits.edit);
router.post("/update/:id", fruits.update);
router.get("/delete/:id", fruits.delete);
export default router;
