/*
    MIT License
    
    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    */
import { Devices, sequelize } from "../models/Devices.js";
await sequelize.sync();
const devices ={
  index: async (req, res) => {
    res.send("Index Page");
  },
  
  insert: async (req, res) => {
    const { Name, Description, Price, Stock, Category }= req.body;
      const e = await Devices.create ({ Name, Description, Price, Stock, Category
    });
     res.status(201).json({
      "status":"true",
      "data": e
    });
  },
  all: async (req, res) =>{
    const data = await Devices.findAll();
    res.json({
      data:data
    });
  },
  findOne: async (req, res) => {
  const id = req.params.id;
  const data = await Devices.findByPk(id);
  res.json({
    data: data
  });
},
  update: async (req, res) => {
    const { id } = req.params;
    const { Name, Description, Price, Stock, Category } = req.body;
    await Devices.update({ Name, Description, Price, Stock, Category }, { where: { id } });
    const updatedData = await Devices.findByPk(id);
    res.json({
      status: "true",
      message: "Successfully updated",
      data: updatedData
    });
  },

  delete: async (req, res) => {
    const {id} = req.params;
    await Devices.destroy({where:{id}});
    res.json({"message": "delete"})
  },

};
export { devices };